from fastapi import APIRouter

from bxk_app.live_option_engine import (
    calculate_iron_condor_credit,
)
from bxk_app.option_scanner import (
    generate_candidate_condors,
    normalize_candidate,
)
from bxk_app.scanner_engine import (
    find_best_iron_condor,
)
from bxk_app.scoring import run_trade_quality
from bxk_app.strategy_ranker import rank_strategies
from bxk_app.trade_builder import (
    build_best_bear_call,
    build_best_bull_put,
    build_best_trade,
)
from bxk_app.wing_optimizer import find_best_trade


router = APIRouter(
    prefix="/api",
    tags=["Scanner"],
)


def safe_market_value(
    market,
    field_name,
    default=None,
):
    """
    Safely read a value from either an object or dictionary.
    """

    if isinstance(market, dict):
        return market.get(
            field_name,
            default,
        )

    return getattr(
        market,
        field_name,
        default,
    )


@router.get("/test-wing-optimizer")
def test_wing_optimizer():
    trade = find_best_trade(
        spx_price=7535.54,
        expected_move=62.5,
    )

    return {
        "trade": trade,
    }


@router.get("/test-scanner-engine")
def test_scanner_engine():
    trade = find_best_iron_condor(
        spx_price=7535.54,
        expected_move=62.5,
        wing_width=25,
        days_to_expiration=1,
    )

    return {
        "trade": trade,
    }


@router.get("/test-candidates")
def test_candidates():
    candidates = generate_candidate_condors(
        spx_price=7535.54,
        expected_move=62.5,
        wing_width=25,
        days_to_expiration=1,
    )

    return {
        "requested_dte": 1,
        "count": len(candidates),
        "selected_dte": (
            candidates[0]["sell_put"].get(
                "days_to_expiration"
            )
            if candidates
            else None
        ),
        "expiration_date": (
            candidates[0]["sell_put"].get(
                "expiration_date"
            )
            if candidates
            else None
        ),
        "first": (
            candidates[0]
            if candidates
            else None
        ),
        "last": (
            candidates[-1]
            if candidates
            else None
        ),
    }


@router.get("/test-first-candidate-credit")
def test_first_candidate_credit():
    raw_candidates = generate_candidate_condors(
        spx_price=7535.54,
        expected_move=62.5,
        wing_width=25,
        days_to_expiration=1,
    )

    if not raw_candidates:
        return {
            "error": "No candidates",
        }

    trade = normalize_candidate(
        raw_candidates[-1],
        spx_price=7535.54,
        expected_move=62.5,
    )

    credit = calculate_iron_condor_credit(
        trade
    )

    return {
        "trade": trade,
        "credit": credit,
    }


@router.get("/test-candidate-grid")
def test_candidate_grid():
    results = []

    for dte in [0, 1, 2, 3]:
        for wing in [5, 10, 20, 25]:
            candidates = generate_candidate_condors(
                spx_price=7535.54,
                expected_move=62.5,
                wing_width=wing,
                days_to_expiration=dte,
            )

            results.append(
                {
                    "dte": dte,
                    "wing": wing,
                    "count": len(
                        candidates
                    ),
                }
            )

    return {
        "results": results,
    }


from fastapi import Query

@router.get("/best-trade")
def best_trade(
    strategy: str = Query(
        default="auto",
        pattern=(
            "^(auto|iron_condor|"
            "bull_put_credit_spread|"
            "bear_call_credit_spread)$"
        ),
    ),
    dte: int = Query(
        default=1,
        ge=0,
        le=30,
    ),
    wing_width: int = Query(
        default=25,
        ge=5,
        le=100,
    ),
    contracts: int = Query(
        default=1,
        ge=1,
        le=50,
    ),
):
    return build_best_trade(
        strategy=strategy,
        wing_width=wing_width,
        days_to_expiration=dte,
        contracts=contracts,
        min_credit=1.00,
    )


@router.get("/best-bull-put")
def best_bull_put():
    return build_best_bull_put(
        wing_width=25,
        days_to_expiration=1,
        min_credit=1.00,
    )


@router.get("/best-bear-call")
def best_bear_call():
    return build_best_bear_call(
        wing_width=25,
        days_to_expiration=1,
        min_credit=1.00,
    )


@router.get("/strategy-rankings")
def strategy_rankings():
    market = run_trade_quality()

    return rank_strategies(
        safe_market_value(
            market,
            "score",
            0,
        ),
        safe_market_value(
            market,
            "trend",
            "UNKNOWN",
        ),
        safe_market_value(
            market,
            "vix_state",
            "UNKNOWN",
        ),
    )